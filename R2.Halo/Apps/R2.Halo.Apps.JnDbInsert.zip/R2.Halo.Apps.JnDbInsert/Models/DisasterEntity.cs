﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace R2.Halo.Apps.JnDbInsert.Models
{
    public class DisasterEntity
    {

        public int Id { set; get; }

        public string 统一编号 { get; set; }
        public string 地理位置 { get; set; }
        public string 名称 { get; set; }
        public string 经度 { get; set; }
        public string 纬度 { get; set; }
        public Nullable<int> 死亡人数 { get; set; }
        public Nullable<int> 威胁人口 { get; set; }
        public Nullable<double> 直接经济损失 { get; set; }
        public Nullable<double> 威胁财产 { get; set; }
        public string 目前稳定状态 { get; set; }
        public string 灾害规模等级 { get; set; }
        public string 灾情等级 { get; set; }
        public string 险情等级 { get; set; }
        public Nullable<double> X坐标 { get; set; }
        public Nullable<double> Y坐标 { get; set; }
        public Nullable<double> 灾害体积 { get; set; }
        public string 灾害类型 { get; set; }
        public string 国际代码 { get; set; }
        public int 真实状态 { get; set; }

    }
}