﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace R2.Halo.Apps.JnDbInsert.Models
{
    class AppJnDbInit<T>:CreateDatabaseIfNotExists<T> where T:DbContext
    {

        private T _dbcontext;


        protected override void Seed(T context)
        {
            this._dbcontext = context;
        }
    }
}