﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;


namespace R2.Halo.Apps.JnDbInsert.Models
{
    public class AppJnDbContext : DbContext
    {

        static AppJnDbContext()
        {
            Database.SetInitializer<AppJnDbContext>(new AppJnDbInit<AppJnDbContext>());
        }


        public AppJnDbContext()
            : base("name=AppJnDb")
        {

        }

        public DbSet<DisasterEntity> Entities { set; get; }

    }
}