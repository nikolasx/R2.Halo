﻿
using System.Data;
using System.Web;
using System.Web.Mvc;
using R2.Halo.Apps.JnDbInsert.Models;

namespace R2.Halo.Apps.JnDbInsert.Controllers
{
    public class JnDbInsertingController : Controller
    {

        private AppJnDbContext db=new AppJnDbContext();
        public ActionResult Index()
        {
            return View("R2.Halo.Apps.JnDbInsert.Views.JnDbInserting.Index");
        }


        public JsonResult AddDisaster(DisasterEntity entity)
        {
            var set = db.Set<DisasterEntity>();
            
            set.Add(entity);
            db.SaveChanges();

            return Json("success");
        }

    }
}
